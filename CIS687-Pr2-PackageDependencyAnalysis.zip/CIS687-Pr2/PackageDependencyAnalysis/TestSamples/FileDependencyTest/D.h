
#include "B.h"
#include "A.h"

class D {
	// return a A and aggregates B at the same time
	A returnA (B* b ) {
	}
}