
#include "B.h"
#include "C.h"

class E {
	B* b;	// aggregates B
};